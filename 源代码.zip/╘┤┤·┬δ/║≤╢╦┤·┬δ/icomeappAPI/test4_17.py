if __name__=="__main__":
    s='abc'
    print(s[0:5])