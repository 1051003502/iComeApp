def get_passwd():
    str='''TGTGNKKjhg#&ZIncjasasdkwjXBR5WZfFw4zhaoshuaixinhhhhkahdkaGDahwdioajkHlsxnklasnYxklamklxsamk'''
    return str[25:35]
if __name__=='__main__':
    print(get_passwd())