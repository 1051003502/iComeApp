import random



if __name__=="__main__":
    #getKey()
